const {DataTypes} = require('sequelize');
const sequelize = require ('../conection_db/conection')

const SignosVitales = sequelize.define('signos_vitales',{
    id:{
        type:DataTypes.INTEGER,
        primaryKey:true,
        unique:true,
    },
    fecha_hora_medicion:{
        type:DataTypes.DATE,
        defaultValue:DataTypes.NOW
    },
    presion_arterial:{
        type:DataTypes.FLOAT
    },
    frecuencia_cardiaca:{
        type:DataTypes.FLOAT
    },
    oxigeno:{
        type:DataTypes.FLOAT
    },
    temperatura:{
        type:DataTypes.FLOAT
    },
    frecuencia_respiratoria:{
        type:DataTypes.FLOAT
    },
    paciente_id:{
        type:DataTypes.INTEGER
    }
},{tableName:'signos_vitales',
    timestamps:false
},
//aca tambien se gestiona createdAt y updatedAt para generar el tiempo cuando se crear.
);

module.exports = SignosVitales;