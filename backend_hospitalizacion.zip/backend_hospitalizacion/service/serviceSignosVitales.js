const SignosVitales = require('../model/modelSignosVitales');

const SignosVitalesService = {
    //Crear registro signos vitales
    create: async(signosVitales) =>{
        try{
            const newSignosVitales = await SignosVitales.create(signosVitales);
            return newSignosVitales;
        }catch(error){
            throw error;}
        }
}
module.exports = SignosVitalesService;