const express = require('express');
const SignosVitalesController = require('./controller/controllerSignosVitales');
const rutas = express.Router();


rutas.post('/medicion',SignosVitalesController.create);

module.exports = rutas;