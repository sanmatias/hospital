const  SignosVitalesService = require('../service/serviceSignosVitales');

const SignosVitalesController = {
    create:async(req,res)=>{
        try{
            const signosVitales = await SignosVitalesService.create(req.body);
            req.status(201).json(signosVitales);
        }catch(error){
            res.status(500).json({message: error.message})
        }
    }
};



module.exports = SignosVitalesController;