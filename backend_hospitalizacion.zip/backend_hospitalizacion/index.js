const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const cors = require('cors');
const Routes = require('./rutes') 
const app = express();
app.use(cors());

const conectDB = require("./conection_db/conection");


//Rutas
app.use(express.json());
app.use(Routes);


app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true}));

app.get('/',(req,res)=>{
  res.sendFile(path.join(__dirname, './templates/index.html'));
});


app.get('/', (req, res) => {
  res.send('¡Hola Mundo!');
});

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Aplicación escuchando en http://localhost:${port}`);
});
  

